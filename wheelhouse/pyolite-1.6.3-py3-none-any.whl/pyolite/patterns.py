USER_PATTERN = r'(\s*)([RW+DC]*)(\s*)=(\s*)%s'
CONFIG_PATTERN = r"(\s*)config(\s*)([\w\.]+)(\s*)=(\s*)([\w\.\"\@\:\/\'\%\^\&\*]+)(\s*)"
