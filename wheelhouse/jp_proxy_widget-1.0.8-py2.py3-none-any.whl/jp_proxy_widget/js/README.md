# Standard javascript

This directory holds javascript useful in conjunction with proxy widgets.
