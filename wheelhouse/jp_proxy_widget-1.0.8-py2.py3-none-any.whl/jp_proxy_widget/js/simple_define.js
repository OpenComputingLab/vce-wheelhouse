// A require.js style module definition.

define([], function() { 
    console.log("loaded simple_define.js"); 
    return {"first_3_primes": [2,3,5]};
})